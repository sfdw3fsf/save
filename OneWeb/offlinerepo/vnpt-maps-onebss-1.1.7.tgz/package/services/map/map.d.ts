import { DefaultMap, MapType, MapOptions } from '../../adapter';
export declare class MapService {
    private static _mapInstance;
    private constructor();
    static init(container: string, options: MapOptions): MapType;
    static get(id: string): DefaultMap;
    static remove(id: string): void;
    static reset(): void;
}
