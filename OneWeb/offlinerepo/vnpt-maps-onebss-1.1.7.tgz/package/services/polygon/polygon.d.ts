import { DefaultPolygon, PolygonLayer, PolygonOptions } from '../../adapter';
import { GeoJSON, PolygonCoordinates } from '../../models';
export declare class PolygonService {
    private static _polygonInstances;
    constructor();
    static init(data: PolygonCoordinates | GeoJSON, options: PolygonOptions): PolygonLayer;
    static get(id: string): DefaultPolygon;
    static remove(id: string): void;
}
