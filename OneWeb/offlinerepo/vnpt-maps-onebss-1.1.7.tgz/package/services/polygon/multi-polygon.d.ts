import { DefaultMultiPolygon, PolygonLayer, PolygonOptions } from '../../adapter';
import { GeoJSONCollection, PolygonCoordinates } from '../../models';
export declare class MultiPolygonService {
    private static _multiPolygonInstances;
    constructor();
    static init(data: PolygonCoordinates[] | GeoJSONCollection, options: PolygonOptions): PolygonLayer;
    static get(id: string): DefaultMultiPolygon;
    static remove(id: string): void;
}
