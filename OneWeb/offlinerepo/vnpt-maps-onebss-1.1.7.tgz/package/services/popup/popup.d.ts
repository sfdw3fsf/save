import { DefaultPopup, PopupType, PopupOptions } from '../../adapter';
import { Coordinates } from '../../models';
export declare class PopupService {
    private static _popupInstances;
    constructor();
    static init(coordinates: Coordinates, content: string, options?: PopupOptions): PopupType;
    static get(popup: PopupType): DefaultPopup;
    static remove(popup: PopupType): void;
}
