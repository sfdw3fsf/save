import { CircleLayer, CircleOptions, DefaultCircle } from '../../adapter';
import { Coordinates } from '../../models';
export declare class CircleService {
    private static _circleInstances;
    constructor();
    static init(coordinates: Coordinates, radius: number, options: CircleOptions): CircleLayer;
    static get(id: string): DefaultCircle;
    static remove(id: string): void;
    static reset(): void;
}
