import { DefaultMultiPoint, PointLayer, PointOptions, PointLngLat } from '../../adapter';
import { CoordinatesArray } from '../../models';
export declare class MultiPointService {
    private static _multiPointInstances;
    constructor();
    static init(data: CoordinatesArray | PointLngLat[], options: PointOptions): PointLayer;
    static get(id: string): DefaultMultiPoint;
    static remove(id: string): void;
}
