import { DefaultPoint, PointLayer, PointOptions, PointLngLat } from '../../adapter';
import { Coordinates } from '../../models';
export declare class PointService {
    private static _pointInstances;
    constructor();
    static init(data: Coordinates | PointLngLat, options: PointOptions): PointLayer;
    static get(id: string): DefaultPoint;
    static remove(id: string): void;
}
