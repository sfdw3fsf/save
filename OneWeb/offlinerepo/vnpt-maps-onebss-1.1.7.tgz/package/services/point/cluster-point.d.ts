import { ClusterPointLayer, ClusterPointOptions, DefaultClusterPoint } from '../../adapter';
import { CoordinatesArray, GeoJSONCollection } from '../../models';
export declare class ClusterPointService {
    private static _clusterPointInstances;
    constructor();
    static init(data: CoordinatesArray | GeoJSONCollection, options: ClusterPointOptions): ClusterPointLayer;
    static get(id: string): DefaultClusterPoint;
    static remove(id: string): void;
}
