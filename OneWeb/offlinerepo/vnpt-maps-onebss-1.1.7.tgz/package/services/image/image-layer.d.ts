import { DefaultImageLayer, ImageOverlayLayer, ImageLayerOptions } from '../../adapter';
import { CoordinatesArray } from '../../models';
export declare class ImageLayerService {
    private static _imageLayerInstances;
    constructor();
    static init(data: CoordinatesArray, options: ImageLayerOptions): ImageOverlayLayer;
    static get(id: string): DefaultImageLayer;
    static remove(id: string): void;
}
