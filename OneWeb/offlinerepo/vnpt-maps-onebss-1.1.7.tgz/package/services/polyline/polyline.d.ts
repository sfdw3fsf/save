import { DefaultPolyline, PolylineLayer, PolylineOptions } from '../../adapter';
import { GeoJSON, LineCoordinates } from '../../models';
export declare class PolylineService {
    private static _polylineInstances;
    constructor();
    static init(data: LineCoordinates | GeoJSON, options: PolylineOptions): PolylineLayer;
    static get(id: string): DefaultPolyline;
    static remove(id: string): void;
}
