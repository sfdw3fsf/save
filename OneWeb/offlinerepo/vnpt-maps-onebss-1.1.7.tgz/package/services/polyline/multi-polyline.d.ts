import { DefaultMultiPolyline, PolylineLayer, PolylineOptions } from '../../adapter';
import { GeoJSONCollection, LineCoordinates } from '../../models';
export declare class MultiPolylineService {
    private static _multiPolylineInstances;
    constructor();
    static init(data: LineCoordinates[] | GeoJSONCollection, options: PolylineOptions): PolylineLayer;
    static get(id: string): DefaultMultiPolyline;
    static remove(id: string): void;
}
