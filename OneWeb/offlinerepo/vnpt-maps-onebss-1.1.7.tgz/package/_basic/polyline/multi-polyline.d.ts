import { PolylineGeometry, PolylineLayer } from '../../adapter';
import { Map } from '../../core';
import { GeoJSONCollection, LineCoordinates, PolylineOptions } from '../../models';
export declare class MultiPolyline {
    instance: PolylineLayer;
    constructor(data: LineCoordinates[] | GeoJSONCollection, options?: PolylineOptions);
    private _getInstance;
    addLayerTo(map: Map): void;
    addPopup(content: string): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    getGeometry(): PolylineGeometry[] | null;
    on(type: string, callback: any): void;
    remove(): void;
}
