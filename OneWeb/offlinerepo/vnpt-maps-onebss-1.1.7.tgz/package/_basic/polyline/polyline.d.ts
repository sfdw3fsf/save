import { PolylineLayer } from '../../adapter';
import { Map } from '../../core';
import { Bound, Centroid, GeoJSON, LineCoordinates, LineStyle, PolylineOptions } from '../../models';
interface PointGeometry {
    type: string;
    coordinates: number[][];
}
export declare class Polyline {
    instance: PolylineLayer;
    constructor(data: LineCoordinates | GeoJSON, options?: PolylineOptions);
    private _getInstance;
    addLayerTo(map: Map): void;
    addPopup(content: string): void;
    bringToFront(): void;
    setStyle(style: LineStyle): void;
    getCoordinates(): LineCoordinates;
    setData(coordinatesArray: LineCoordinates): void;
    getGeometry(): PointGeometry | null;
    getLength(): number;
    getCentroid(): Centroid | null;
    getBounds(): Bound | null;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    on(type: string, callback: any): void;
    rotate(degree: number): void;
    remove(): void;
}
export {};
