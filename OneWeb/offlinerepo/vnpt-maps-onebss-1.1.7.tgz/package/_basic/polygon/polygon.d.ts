import { PolygonLayer } from '../../adapter';
import { Map } from '../../core';
import { Bound, Centroid, GeoJSON, PolygonCoordinates, PolygonOptions, PolygonStyle } from '../../models';
export declare class Polygon {
    instance: PolygonLayer;
    constructor(data: PolygonCoordinates | GeoJSON, options?: PolygonOptions);
    private _getInstance;
    addLayerTo(map: Map): void;
    addPopup(content: string): void;
    getCoordinates(): PolygonCoordinates;
    getGeometry(): any | null;
    setData(coordinatesArray: PolygonCoordinates): void;
    getVisible(): boolean;
    setVisble(isVisible: boolean): void;
    getArea(): number;
    getCentroid(): Centroid | null;
    getBounds(): Bound | null;
    rotate(degree: number): void;
    remove(): void;
    setStyle(style: PolygonStyle): void;
    on(type: string, callback: any): void;
}
