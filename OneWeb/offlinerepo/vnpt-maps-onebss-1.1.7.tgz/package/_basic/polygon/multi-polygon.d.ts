import { MultiPolygonGeometry, PolygonLayer } from '../../adapter';
import { Map } from '../../core';
import { GeoJSONCollection, PolygonCoordinates, PolygonOptions } from '../../models';
export declare class MultiPolygon {
    instance: PolygonLayer;
    constructor(data: PolygonCoordinates[] | GeoJSONCollection, options?: PolygonOptions);
    private _getInstance;
    addLayerTo(map: Map): void;
    addPopup(content: string): void;
    getCoordinates(): PolygonCoordinates[];
    getGeometry(): MultiPolygonGeometry | null;
    getVisible(): boolean;
    setVisble(isVisible: boolean): void;
    on(type: string, callback: any): void;
    remove(): void;
}
