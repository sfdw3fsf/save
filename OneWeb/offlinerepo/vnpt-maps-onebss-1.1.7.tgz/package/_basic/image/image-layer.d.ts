import { ImageOverlayLayer } from '../../adapter';
import { Map } from '../../core';
import { CoordinatesArray, ImageLayerOptions } from '../../models';
export declare class ImageLayer {
    instance: ImageOverlayLayer;
    constructor(coordinatesArray: CoordinatesArray, options?: ImageLayerOptions);
    private _getInstance;
    addLayerTo(map: Map): void;
    bringToFront(): void;
    bringBack(beforeId: string): void;
    getUrl(): string;
    setUrl(url: string): void;
    getVisible(): boolean;
    setVisible(visible: boolean): void;
    remove(): void;
}
