import { PointGeometry, PointLayer, PointLngLat } from '../../adapter';
import { Map } from '../../core';
import { CoordinatesArray, PointOptions } from '../../models';
export declare class MultiPoint {
    instance: PointLayer;
    constructor(data: CoordinatesArray | PointLngLat[], options?: PointOptions);
    private _getInstance;
    addLayerTo(map: Map): void;
    addPopup(content: string): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    getCoordinates(): CoordinatesArray;
    getGeometry(): PointGeometry | null;
    eachPoint(callback: any): void;
    remove(): void;
}
