import { ClusterPointLayer } from '../../adapter';
import { Map } from '../../core';
import { ClusterPointOptions, Coordinates, CoordinatesArray, GeoJSONCollection } from '../../models';
export declare class ClusterPoint {
    instance: ClusterPointLayer;
    constructor(data: CoordinatesArray | GeoJSONCollection, options?: ClusterPointOptions);
    private _getInstance;
    addLayerTo(map: Map): void;
    addPopup(content: string): void;
    addPoint(coordinates: Coordinates): void;
    addMultiPoint(lineCoordinates: CoordinatesArray): void;
    removePoint(coordinates: Coordinates): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    on(type: string, callback: any): void;
    remove(): void;
}
