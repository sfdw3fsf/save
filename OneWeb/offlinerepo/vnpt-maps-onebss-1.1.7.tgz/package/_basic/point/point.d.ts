import { PointLayer } from '../../adapter';
import { Map } from '../../core';
import { Coordinates, GeoJSON, PointOptions } from '../../models';
interface PointGeometry {
    type: string;
    coordinates: Coordinates;
}
export declare class Point {
    instance: PointLayer;
    constructor(data: Coordinates | GeoJSON, options?: PointOptions);
    private _getInstance;
    addLayerTo(map: Map): void;
    addPopup(content: string): void;
    getCoordinates(): Coordinates;
    setData(coordinates: Coordinates): void;
    getGeometry(): PointGeometry | null;
    setIcon(iconUrl: string): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    remove(): void;
    on(map: Map, type: string, callback: any): void;
    setHover(): void;
    onDragEnd(): void;
    doubleClick(map: Map): void;
    onDrag(type: string, callback: any): void;
    isDraggable(): boolean;
    setDraggable(draggable: boolean): void;
    setLabel(text: string): void;
    setLabelVisible(isVisible: boolean): void;
}
export {};
