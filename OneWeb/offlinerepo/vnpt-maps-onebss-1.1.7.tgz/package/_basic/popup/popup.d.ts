import { PopupLayer } from '../../adapter';
import { Coordinates, PopupOptions } from '../../models';
import { Map } from '../../core';
export declare class Popup {
    instance: PopupLayer;
    constructor(coordinates: Coordinates, content: string, options?: PopupOptions);
    private _getInstance;
    addLayerTo(map: Map): void;
    getPosition(): Coordinates;
    setPosition(coordinates: Coordinates): void;
    getContent(): string;
    setContent(content: string): void;
    getContentHtml(): string;
    setHtml(content: string): void;
    setStyle(style: string): void;
    remove(): void;
}
