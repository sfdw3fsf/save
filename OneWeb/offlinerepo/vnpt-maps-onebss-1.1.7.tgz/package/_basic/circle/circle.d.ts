import { CircleLayer } from '../../adapter';
import { Map } from '../../core';
import { CircleOptions, Coordinates } from '../../models';
export declare class Circle {
    instance: CircleLayer;
    constructor(coordinates: Coordinates, radius: number, options?: CircleOptions);
    private _getInstance;
    addLayerTo(map: Map): void;
    addPopup(content: string): void;
    getCenter(): Coordinates;
    setCenter(center: Coordinates): void;
    getRadius(): number;
    setRadius(radiusValue: number): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    on(type: string, callback: any): void;
    remove(): void;
}
