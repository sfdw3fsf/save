export declare class Utils {
    constructor();
    static LIST_OF_LATITUDE: string[];
    static LIST_OF_LONGITUDE: string[];
    static LIST_OF_VEHICAL: string[];
    static FormatToStandardLonLat(data: any): {};
    static FormatToStandardCoordinates(data: number[]): number[];
    static TimeConversion(millisec: any): string;
    static SuggestRoute(array: any): {
        instructions: any;
        index: any;
    }[];
    static CheckAndFormatToStandardPolylineLayer(data: any): any;
    static CheckAndFormatToStandardPolygonLayer(data: any): any;
    static transformFromWGS84(coordinates: number[], toSRID: string): number[] | undefined;
    static toDegreesMinutesAndSeconds(coordinate: number): any;
    static convertDEGToDMS(lat: number, lng: number): any;
    static convertDMSToDEG(dms: any): any;
    static splitPolygon(polygon: any, line: any, idPrefix: any): any;
    static joinLine(line1: any, line2: any): any;
}
