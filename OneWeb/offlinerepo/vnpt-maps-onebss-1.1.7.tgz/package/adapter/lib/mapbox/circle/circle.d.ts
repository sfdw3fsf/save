import { VectorLayer } from '../core';
import { CircleLayer, CircleOptions, ICircle } from '../../../models';
import { Coordinates } from '../../../../models';
export declare class DefaultCircle extends VectorLayer implements ICircle {
    private _center;
    private _radius;
    circle: CircleLayer;
    constructor(data: Coordinates, radius: number, options: CircleOptions);
    private _getGeoJSON;
    addLayerTo(mapId: string): void;
    addPopup(content: string): void;
    getCenter(): Coordinates;
    setCenter(center: Coordinates): void;
    getRadius(): number;
    setRadius(radiusValue: number): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    on(type: string, callback: any): void;
    remove(): void;
}
