import { VectorLayer } from '../core';
import { IPolyline, PolylineLayer, PolylineOptions } from '../../../models';
import { Bound, Centroid, GeoJSON, LineCoordinates, LineStyle } from '../../../../models';
export declare class DefaultPolyline extends VectorLayer implements IPolyline {
    polyline: PolylineLayer;
    constructor(data: LineCoordinates | GeoJSON, options: PolylineOptions);
    private _setHover;
    addLayerTo(mapId: string): void;
    addPopup(content: string): void;
    bringToFront(): void;
    getCoordinates(): any;
    setData(coordinatesArray: LineCoordinates): void;
    setStyle(style: LineStyle): PolylineLayer;
    getLength(): number;
    getCentroid(): Centroid | null;
    getBounds(): Bound | null;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    on(type: string, callback: any): void;
    rotate(degree: number): void;
    remove(): void;
}
