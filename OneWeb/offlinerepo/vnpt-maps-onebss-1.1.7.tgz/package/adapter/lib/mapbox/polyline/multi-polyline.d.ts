import { VectorGroupLayer } from '../core';
import { IMultiPolyline, PolylineGeometry, PolylineLayer, PolylineOptions } from '../../../models';
import { GeoJSONCollection, LineCoordinates } from '../../../../models';
export declare class DefaultMultiPolyline extends VectorGroupLayer implements IMultiPolyline {
    multiPolyline: PolylineLayer;
    constructor(data: LineCoordinates[] | GeoJSONCollection, options: PolylineOptions);
    addLayerTo(mapId: string): void;
    addPopup(content: string): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    getGeometry(): PolylineGeometry[] | null;
    on(type: string, callback: any): void;
    remove(): void;
}
