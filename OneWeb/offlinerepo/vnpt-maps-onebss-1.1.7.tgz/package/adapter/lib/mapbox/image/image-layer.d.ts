import { Layer } from '../core';
import { IImageLayer, ImageOverlayLayer, ImageLayerOptions } from '../../../models';
import { CoordinatesArray } from '../../../../models';
export declare class DefaultImageLayer extends Layer implements IImageLayer {
    private _sourceGeoJSON;
    image: ImageOverlayLayer;
    constructor(data: CoordinatesArray, options: ImageLayerOptions);
    addLayerTo(mapId: string): void;
    bringToFront(): void;
    bringToBack(beforeId: string): void;
    getUrl(): string;
    setUrl(url: string): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    remove(): void;
}
