export declare class MapIconStore {
    private static _mapIconStorage;
    constructor();
    private static getIconStore;
    private static hasIconStore;
    private static initIconStore;
    static getIconId(mapId: string, iconUrl: string): string;
    static hasIconUrl(mapId: string, iconUrl: string): boolean;
    static saveIconUrl(mapId: string, iconUrl: string): void;
}
