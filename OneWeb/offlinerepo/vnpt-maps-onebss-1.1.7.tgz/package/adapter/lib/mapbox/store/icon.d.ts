export declare class IconStore {
    private _mapId;
    private _iterator;
    private _iconStorage;
    constructor(mapId: string);
    getIconId(iconUrl: string): string;
    hasIconUrl(iconUrl: string): boolean;
    saveIconUrl(iconUrl: string): void;
}
