import { VectorLayer } from '../core';
import { IPolygon, PolygonLayer, PolygonOptions } from '../../../models';
import { Bound, Centroid, GeoJSON, PolygonCoordinates, PolygonStyle } from '../../../../models';
export declare class DefaultPolygon extends VectorLayer implements IPolygon {
    polygon: PolygonLayer;
    constructor(data: PolygonCoordinates | GeoJSON, options: PolygonOptions);
    addLayerTo(mapId: string): void;
    private _setHover;
    addPopup(content: string): void;
    rotate(degree: number): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    getCoordinates(): PolygonCoordinates;
    setData(coordinatesArray: PolygonCoordinates): void;
    getCentroid(): Centroid | null;
    getBounds(): Bound | null;
    getArea(): number;
    on(type: string, callback: any): void;
    remove(): void;
    setStyle(style: PolygonStyle): PolygonLayer;
}
