import { VectorGroupLayer } from '../core';
import { IMultiPolygon, PolygonLayer, PolygonOptions } from '../../../models';
import { GeoJSONCollection, PolygonCoordinates } from '../../../../models';
export declare class DefaultMultiPolygon extends VectorGroupLayer implements IMultiPolygon {
    multiPolygon: PolygonLayer;
    constructor(data: PolygonCoordinates[] | GeoJSONCollection, options: PolygonOptions);
    addLayerTo(mapId: string): void;
    addPopup(content: string): void;
    getCoordinates(): PolygonCoordinates[];
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    on(type: string, callback: any): void;
    remove(): void;
}
