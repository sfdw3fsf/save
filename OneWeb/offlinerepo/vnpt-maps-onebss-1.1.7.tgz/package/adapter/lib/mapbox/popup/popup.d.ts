import { PopupType } from '../../..';
import { IPopup } from '../../../models';
import { Coordinates, PopupOptions } from '../../../../models';
export declare class DefaultPopup implements IPopup {
    popup: PopupType;
    contenValue: string;
    contentHtml: string;
    constructor(coordinates: Coordinates, content: string, options?: PopupOptions);
    addLayerTo(mapId: string): void;
    getPosition(): Coordinates;
    setPosition(coordinates: Coordinates): void;
    getContent(): string;
    setContent(content: string): void;
    getContentHtml(): string;
    setHtml(htmlString: string): void;
    setStyle(className: string): void;
    private clearData;
    remove(): void;
}
