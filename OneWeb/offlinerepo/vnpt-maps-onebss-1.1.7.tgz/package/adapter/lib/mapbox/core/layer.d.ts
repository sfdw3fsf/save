import { MapType } from '..';
import { LayerCoordinates } from '../../../models';
interface SourceOptions {
    type: string;
    data?: any;
    geometry?: any;
    url?: string;
    coordinates?: LayerCoordinates;
    cluster?: boolean;
}
export declare class Layer {
    protected _mapId: string;
    constructor();
    protected setMapId(id: string): void;
    protected getMapInstance(id: string): MapType;
    protected addSource(mapId: string, id: string, options: SourceOptions): void;
    protected getSource(mapId: string, id: string): any;
    protected removeSource(mapId: string, id: string): void;
}
export {};
