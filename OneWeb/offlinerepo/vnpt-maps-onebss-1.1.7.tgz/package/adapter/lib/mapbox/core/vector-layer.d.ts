import { Layer } from './layer';
import { LayerCoordinates, LayerOptions, LayerType } from '../../../models';
import { GeoJSON } from '../../../../models';
export declare class VectorLayer extends Layer {
    protected _sourceGeoJSON: any;
    constructor(data: LayerCoordinates | GeoJSON, type: LayerType, options: LayerOptions, properties?: any);
}
