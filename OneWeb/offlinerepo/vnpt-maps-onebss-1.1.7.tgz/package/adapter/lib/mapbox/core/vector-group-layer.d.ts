import { Layer } from './layer';
import { GroupLayerCoordinates, LayerOptions, LayerGroupType } from '../../../models';
import { GeoJSONCollection } from '../../../../models';
export declare class VectorGroupLayer extends Layer {
    protected _sourceGeoJSON: any;
    constructor(data: GroupLayerCoordinates | GeoJSONCollection, type: LayerGroupType, options: LayerOptions, properties?: any);
}
