import { PointLngLat } from '../../..';
import { IMultiPoint, PointLayer, PointOptions } from '../../../models';
import { CoordinatesArray } from '../../../../models';
export declare class DefaultMultiPoint implements IMultiPoint {
    private _points;
    multiPoint: PointLayer;
    constructor(data: CoordinatesArray | PointLngLat[], options: PointOptions);
    addLayerTo(mapId: string): void;
    addPopup(content: string): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    getCoordinates(): CoordinatesArray;
    eachPoint(callback: any): void;
    remove(): void;
}
