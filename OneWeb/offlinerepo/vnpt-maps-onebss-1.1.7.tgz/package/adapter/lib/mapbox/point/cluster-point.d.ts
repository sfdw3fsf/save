import { VectorGroupLayer } from '../core';
import { ClusterPointLayer, IClusterPoint, ClusterPointOptions } from '../../../models';
import { Coordinates, CoordinatesArray, GeoJSONCollection } from '../../../../models';
export declare class DefaultClusterPoint extends VectorGroupLayer implements IClusterPoint {
    private _iconUrl;
    clusterPoint: ClusterPointLayer;
    constructor(data: CoordinatesArray | GeoJSONCollection, options: ClusterPointOptions);
    private _loadImage;
    private _setIconImage;
    private _addIconImage;
    private _mergeSteps;
    private _setInteraction;
    private _addLayer;
    addLayerTo(mapId: string): void;
    addPopup(content: string): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    private getFeaturesSource;
    private setDataSource;
    on(type: string, callBack: any): void;
    addPoint(coordinates: Coordinates): void;
    addMultiPoint(coordinatesArray: CoordinatesArray): void;
    removePoint(coordinates: Coordinates): void;
    remove(): void;
}
