import { PointLngLat } from '..';
import { IPoint, PointLayer, PointOptions } from '../../../models';
import { Coordinates } from '../../../../models';
export declare class DefaultPoint implements IPoint {
    private _point;
    point: PointLayer;
    constructor(coordinates: Coordinates | PointLngLat, options: PointOptions);
    addLayerTo(mapId: string): void;
    addPopup(content: string): void;
    getId(): string;
    getCoordinates(): Coordinates;
    setData(coordinates: Coordinates | PointLngLat): void;
    setIcon(iconUrl: string): void;
    getVisible(): boolean;
    setVisible(isVisible: boolean): void;
    remove(): void;
    on(mapId: string, type: string, callBack: any): void;
    setHover(): void;
    doubleClick(mapId: string): void;
    private _onDragEnd;
    onDragEnd(): void;
    onDrag(type: string, callBack: any): void;
    setDraggable(draggable: boolean): void;
    isDraggable(): boolean;
    setLabel(text: string): void;
    setLabelVisible(isVisible: boolean): void;
}
