import Map from 'ol/Map';
import { MapOptions } from '../../../models';
export declare class OpenLayersLib {
    constructor(container: string, options: MapOptions);
}
export declare type OpenLayersMap = Map;
