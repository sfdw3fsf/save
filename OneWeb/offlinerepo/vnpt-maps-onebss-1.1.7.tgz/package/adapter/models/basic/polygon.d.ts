import { Centroid, Bound, PolygonCoordinates, CoordinatesArray } from '../../../models';
export interface PointGeometry {
    type: string;
    coordinates: CoordinatesArray;
}
export interface MultiPolygonGeometry {
    type: string;
    coordinates: PolygonCoordinates[];
}
interface ICommonPolygon {
    addLayerTo: (mapId: string) => void;
    addPopup: (content: string) => void;
    getVisible: () => boolean;
    setVisible: (isVisible: boolean) => void;
    remove: () => void;
    on: (type: string, callback: any) => void;
}
export interface IPolygon extends ICommonPolygon {
    getCoordinates?: () => PolygonCoordinates;
    setData: (coordinatesArray: PolygonCoordinates) => void;
    rotate: (degree: number) => void;
    getCentroid: () => Centroid | null;
    getBounds: () => Bound | null;
    getArea: () => number;
}
export interface IMultiPolygon extends ICommonPolygon {
    getCoordinates: () => PolygonCoordinates[];
}
export interface PolygonLayer {
    id: string;
    line: {
        id: string;
        type: string;
        source: string;
        layout: any;
        paint: {
            'line-color': string;
            'line-width': number;
            'line-dasharray': number[];
            'line-opacity': number;
        };
    };
    fill: {
        id: string;
        type: string;
        source: string;
        layout: any;
        paint: {
            'fill-color': string;
            'fill-opacity': number;
        };
    };
}
export interface PolygonOptions {
    id: string;
    color: string;
    dashArray: number[];
    fillColor: string;
    fillOpacity: number;
    opacity: number;
    weight: number;
}
export {};
