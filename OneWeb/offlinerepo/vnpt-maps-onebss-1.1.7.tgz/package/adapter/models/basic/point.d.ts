import { FlyToOptions } from './../map';
import { Coordinates, CoordinatesArray } from '../../../models';
interface ICommonPoint {
    addLayerTo: (mapId: string) => void;
    addPopup: (content: string) => void;
    getVisible: () => boolean;
    setVisible: (isVisible: boolean) => void;
    remove: () => void;
    on?: (mapId: string, type: string, callback: any) => void;
}
export interface IPoint extends ICommonPoint {
    getCoordinates: () => Coordinates;
    setIcon: (iconUrl: string) => void;
    setData: (coordinates: Coordinates) => void;
    doubleClick?: (mapId: string, options?: FlyToOptions) => void;
    setHover: () => void;
    onDragEnd: () => void;
    onDrag: (type: string, callback: any) => void;
    isDraggable: () => boolean;
    setDraggable: (draggable: boolean) => void;
    setLabel: (text: string) => void;
    setLabelVisible: (isVisible: boolean) => void;
}
export interface IMultiPoint extends ICommonPoint {
    getCoordinates: () => CoordinatesArray;
    eachPoint: (callback: any) => void;
}
export interface PointLayer {
    id: string;
    className: string;
    iconHeight: number;
    iconOpacity: number;
    iconUrl: string;
    iconWidth: number;
    isDraggable: boolean;
}
export declare type PointOptions = PointLayer;
export {};
