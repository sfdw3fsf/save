import { Layer } from './layer';
import { Coordinates, LineCoordinates } from '../../../models';
export interface IClusterPoint {
    addLayerTo: (mapId: string) => void;
    addPopup: (content: string) => void;
    getVisible: () => boolean;
    setVisible: (isVisible: boolean) => void;
    addPoint: (coordinates: Coordinates) => void;
    addMultiPoint: (lineCoordinates: LineCoordinates) => void;
    removePoint: (coordinates: Coordinates) => void;
    on: (type: string, id: string, callback: any) => void;
    remove: () => void;
}
export interface ClusterPointLayer {
    id: string;
    cluster: ClusterPoint;
    clusterCount: ClusterCount;
    unclusteredPoint: UnclusteredPoint;
}
export interface ClusterPointOptions {
    id: string;
    iconSize: number;
    iconUrl: string;
    iconOpacity: number;
    clickToZoom: boolean;
    clusterColors: string[];
    clusterRadiuses: number[];
    clusterSteps: number[];
    clusterOpacity: number;
}
interface ClusterPoint extends Layer {
    filter: ['has', 'point_count'];
    paint: {
        'circle-color': any;
        'circle-radius': any;
        'circle-opacity': number;
    };
    layout: any;
}
interface ClusterCount extends Layer {
    filter: ['has', 'point_count'];
    layout: {
        'text-field': string;
        'text-font': string[];
        'text-size': number;
        visibility: string;
    };
}
interface UnclusteredPoint extends Layer {
    filter: ['!', ['has', 'point_count']];
    id: string;
    type: string;
    source: string;
    layout: {
        'icon-image': string;
        'icon-size': number;
        'icon-allow-overlap': boolean;
        visibility: string;
    };
    paint: {
        'icon-opacity': number;
    };
}
export interface FeaturesClusterPoint {
    type: string;
    geometry: {
        type: string;
        coordinates: Coordinates;
    };
}
export {};
