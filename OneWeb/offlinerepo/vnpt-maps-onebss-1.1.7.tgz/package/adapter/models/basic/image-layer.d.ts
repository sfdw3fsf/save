export interface IImageLayer {
    addLayerTo: (mapId: string) => void;
    bringToFront: () => void;
    bringToBack: (beforeId: string) => void;
    getUrl: () => string;
    setUrl: (url: string) => void;
    getVisible: () => boolean;
    setVisible: (isVisible: boolean) => void;
    remove: () => void;
}
export interface ImageOverlayLayer {
    id: string;
    type: string;
    source: string;
    layout: any;
    paint: {
        'raster-opacity': number;
        'raster-fade-duration': number;
    };
}
export interface ImageLayerOptions {
    id: string;
    fadeDuration: number;
    opacity: number;
    url: string;
}
