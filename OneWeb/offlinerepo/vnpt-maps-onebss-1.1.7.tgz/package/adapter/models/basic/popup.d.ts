import { Coordinates } from '../../../models';
import { PopupType } from '../../lib';
export interface PopupLayer {
    id: string;
    popup: PopupType;
}
export interface PopupOptions {
    id: string;
    offset: number;
}
export interface IPopup {
    addLayerTo: (mapId: string) => void;
    getPosition: () => Coordinates;
    setPosition: (coordinates: Coordinates) => void;
    getContent: () => string;
    setContent: (content: string) => void;
    getContentHtml: () => string;
    setHtml: (htmlString: string) => void;
    setStyle: (style: string) => void;
    remove: () => void;
}
