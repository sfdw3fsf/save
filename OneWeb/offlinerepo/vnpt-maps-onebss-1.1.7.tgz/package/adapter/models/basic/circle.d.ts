import * as turf from '@turf/turf';
import { Coordinates } from '../../../models';
import { PolygonLayer, PolygonOptions } from './polygon';
export interface ICircle {
    addLayerTo: (mapId: string) => void;
    addPopup: (content: string) => void;
    getCenter: () => Coordinates;
    setCenter: (center: Coordinates) => void;
    getRadius: () => number;
    setRadius: (radiusValue: number) => void;
    getVisible: () => boolean;
    setVisible: (isVisible: boolean) => void;
    on: (type: string, callback: any) => void;
    remove: () => void;
}
export declare type CircleLayer = PolygonLayer;
export declare type CircleOptions = PolygonOptions;
interface TurfCircleOptions {
    steps: number;
    units: turf.Units;
}
export declare const DEFAULT_CIRCLE_OPTIONS: TurfCircleOptions;
export {};
