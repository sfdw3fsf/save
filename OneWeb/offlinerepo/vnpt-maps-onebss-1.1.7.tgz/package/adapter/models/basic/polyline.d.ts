import { Layer } from './layer';
import { Centroid, Bound, LineCoordinates, CoordinatesArray } from '../../../models';
interface ICommonPolyline {
    addLayerTo: (mapId: string) => void;
    addPopup: (content: string) => void;
    getVisible: () => boolean;
    setVisible: (isVisible: boolean) => void;
    on: (type: string, callback: any) => void;
    remove: () => void;
}
export interface IPolyline extends ICommonPolyline {
    getCoordinate?: () => LineCoordinates;
    setData: (coordinatesArray: LineCoordinates) => void;
    getLength: () => number;
    getCentroid: () => Centroid | null;
    getBounds: () => Bound | null;
    rotate: (degree: number) => void;
}
export interface IMultiPolyline extends ICommonPolyline {
    getGeometry: () => PolylineGeometry[] | null;
}
export interface PolylineLayer extends Layer {
    layout: {
        'line-cap': string;
        'line-join': string;
        visibility: string;
    };
    paint: {
        'line-color': string;
        'line-width': number;
        'line-dasharray': number[];
        'line-opacity': number;
    };
}
export interface PolylineOptions {
    id: string;
    color: string;
    dashArray: number[];
    lineCap: string;
    opacity: number;
    weight: number;
}
export interface PolylineGeometry {
    type: string;
    geometry: {
        type: string;
        coordinates: CoordinatesArray;
    };
}
export {};
