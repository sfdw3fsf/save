export interface Layer {
    id: string;
    type: string;
    source: string;
}
