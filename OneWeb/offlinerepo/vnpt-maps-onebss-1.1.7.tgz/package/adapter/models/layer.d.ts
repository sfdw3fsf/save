import { Coordinates, CoordinatesArray, LineCoordinates, PolygonCoordinates } from '../../models';
export declare type LayerType = 'Point' | 'LineString' | 'Polygon';
export declare type LayerGroupType = 'Point' | 'LineString' | 'MultiPolygon';
export declare type LayerOptions = {
    id: string;
};
export declare type LayerCoordinates = Coordinates | CoordinatesArray | LineCoordinates | PolygonCoordinates;
export declare type GroupLayerCoordinates = Coordinates[] | CoordinatesArray[] | LineCoordinates[] | PolygonCoordinates[];
