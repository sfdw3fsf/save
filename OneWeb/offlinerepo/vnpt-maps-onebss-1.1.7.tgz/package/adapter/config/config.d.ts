export declare const config: {
    useMapLib: string;
};
