import { LayerOptions } from './layer';
export interface PopupOptions extends LayerOptions {
    offset?: number;
}
