import { LayerOptions } from './layer';
export interface PolygonStyle {
    color?: string;
    dashArray?: number[];
    fillColor?: string;
    fillOpacity?: number;
    opacity?: number;
    weight?: number;
}
export interface PolygonOptions extends LayerOptions, PolygonStyle {
}
