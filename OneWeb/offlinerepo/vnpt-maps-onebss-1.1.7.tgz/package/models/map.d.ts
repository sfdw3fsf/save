import { Coordinates } from './layer';
export interface MapOptions {
    bearing?: number;
    center?: Coordinates;
    id?: string;
    maxZoom?: number;
    minZoom?: number;
    pitch?: number;
    showZoomControl?: boolean;
    showFullscreen?: boolean;
    styleUrl?: string;
    token?: string;
    zoom?: number;
    zoomControlPosition?: string;
    fullscreenPosition?: string;
    isRaster?: boolean;
}
export declare type FlyToOptions = {
    duration?: number;
};
export declare type AnimationOptions = {
    duration?: number;
    animate?: boolean;
};
export declare type BoundOptions = {
    linear?: boolean;
    maxZoom?: number;
    padding?: Padding;
    offset?: Coordinates;
};
export declare type Padding = {
    top?: number;
    bottom?: number;
    left?: number;
    right?: number;
};
