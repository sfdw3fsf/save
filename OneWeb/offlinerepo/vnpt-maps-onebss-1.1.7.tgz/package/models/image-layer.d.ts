import { LayerOptions } from './layer';
export interface ImageLayerOptions extends LayerOptions {
    fadeDuration?: number;
    opacity?: number;
    url: string;
}
