import { Coordinates, LayerOptions } from './layer';
export interface LineStyle {
    color?: string;
    dashArray?: number[];
    lineCap?: string;
    opacity?: number;
    weight?: number;
}
export interface PolylineOptions extends LayerOptions, LineStyle {
}
export interface Centroid {
    geometry?: {
        coordinates?: Coordinates;
        type?: string;
    };
    type?: string;
}
export interface Bound {
    bounds?: number[];
    geometry?: {
        coordinates?: number[][][];
    };
}
