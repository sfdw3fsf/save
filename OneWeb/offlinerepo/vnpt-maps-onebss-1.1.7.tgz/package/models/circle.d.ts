import { LayerOptions } from './layer';
export interface CircleStyle {
    color?: string;
    dashArray?: number[];
    fillColor?: string;
    fillOpacity?: number;
    opacity?: number;
    weight?: number;
}
export interface CircleOptions extends LayerOptions, CircleStyle {
}
