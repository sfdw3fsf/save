import { Circle, ClusterPoint, ImageLayer, MultiPolyline, MultiPolygon, Polygon, Polyline } from '../_basic';
export interface LayerOptions {
    id?: string;
}
export declare type GeoJSONCollection = {
    type: string;
    features: GeoJSON[];
};
export declare type GeoJSON = {
    type: string;
    geometry: any;
    properties?: any;
};
export declare type Coordinates = number[];
export declare type CoordinatesArray = Coordinates[];
export declare type LineCoordinates = CoordinatesArray;
export declare type PolygonCoordinates = CoordinatesArray[];
export declare type FeatureLayer = Circle | ClusterPoint | ImageLayer | MultiPolyline | MultiPolygon | Polyline | Polygon;
