import { LayerOptions } from './layer';
export interface PointOptions extends LayerOptions {
    className?: string;
    iconHeight?: number;
    iconOpacity?: number;
    iconUrl?: string;
    iconWidth?: number;
    isDraggable?: boolean;
}
