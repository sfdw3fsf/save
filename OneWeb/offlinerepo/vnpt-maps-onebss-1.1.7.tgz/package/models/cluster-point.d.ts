import { LayerOptions } from './layer';
export interface ClusterPointOptions extends LayerOptions {
    iconSize?: number;
    iconUrl?: string;
    iconOpacity?: number;
    clickToZoom?: boolean;
    clusterColors?: string[];
    clusterRadiuses?: number[];
    clusterSteps?: number[];
    clusterOpacity?: number;
}
