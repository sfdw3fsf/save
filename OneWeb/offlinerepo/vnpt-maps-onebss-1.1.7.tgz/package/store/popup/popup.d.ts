import { Popup } from '../../_basic';
export declare class PopupStore {
    private static _iterator;
    private static _popupStorage;
    constructor();
    static getIterator(): number;
    static addInstance(popup: Popup): void;
    static getInstance(id: string): Popup | undefined;
    static removeInstance(id: string): void;
}
