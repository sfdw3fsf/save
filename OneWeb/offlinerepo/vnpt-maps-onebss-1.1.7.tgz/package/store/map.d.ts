import { Map as FeatureMap } from '../core';
export declare class MapStore {
    private static _iterator;
    private static _mapStorage;
    constructor();
    static getIterator(): number;
    static addInstance(mapInstance: FeatureMap): void;
    static getInstance(id: string): FeatureMap | undefined;
    static removeInstance(id: string): void;
    static removeMapInstance(): void;
}
