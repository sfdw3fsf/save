import { Polyline } from '../../_basic';
export declare class PolylineStore {
    private static _iterator;
    private static _polylineStorage;
    constructor();
    static getIterator(): number;
    static addInstance(polyline: Polyline): void;
    static getInstance(id: string): Polyline | undefined;
    static removeInstance(id: string): void;
}
