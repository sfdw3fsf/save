import { MultiPolyline } from '../../_basic';
export declare class MultiPolylineStore {
    private static _iterator;
    private static _multiPolylineStorage;
    constructor();
    static getIterator(): number;
    static addInstance(multiPolyline: MultiPolyline): void;
    static getInstance(id: string): MultiPolyline | undefined;
    static removeInstance(id: string): void;
}
