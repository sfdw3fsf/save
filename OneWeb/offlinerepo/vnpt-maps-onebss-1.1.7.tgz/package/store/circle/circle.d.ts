import { Circle } from '../../_basic';
export declare class CircleStore {
    private static _iterator;
    private static _circleStorage;
    constructor();
    static getIterator(): number;
    static addInstance(circle: Circle): void;
    static getInstance(id: string): Circle | undefined;
    static removeInstance(id: string): void;
    static reset(): void;
}
