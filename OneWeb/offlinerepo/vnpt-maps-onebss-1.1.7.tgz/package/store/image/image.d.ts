import { ImageLayer } from '../../_basic';
export declare class ImageLayerStore {
    private static _iterator;
    private static _imageStorage;
    constructor();
    static getIterator(): number;
    static addInstance(image: ImageLayer): void;
    static getInstance(id: string): ImageLayer | undefined;
    static removeInstance(id: string): void;
}
