import { Polygon } from '../../_basic';
export declare class PolygonStore {
    private static _iterator;
    private static _polygonStorage;
    constructor();
    static getIterator(): number;
    static addInstance(polygon: Polygon): void;
    static getInstance(id: string): Polygon | undefined;
    static removeInstance(id: string): void;
}
