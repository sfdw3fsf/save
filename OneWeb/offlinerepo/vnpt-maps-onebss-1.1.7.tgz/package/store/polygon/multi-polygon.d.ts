import { MultiPolygon } from '../../_basic';
export declare class MultiPolygonStore {
    private static _iterator;
    private static _multiPolygonStorage;
    constructor();
    static getIterator(): number;
    static addInstance(circle: MultiPolygon): void;
    static getInstance(id: string): MultiPolygon | undefined;
    static removeInstance(id: string): void;
}
