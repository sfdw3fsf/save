import { Instance, INSTANCE_TYPE } from '.';
export declare class Store {
    constructor();
    static addInstance<T extends Instance>(instance: T, type: INSTANCE_TYPE): void;
    static getInstance<T extends Instance>(id: string, type: INSTANCE_TYPE): T | undefined;
    static removeInstance(id: string, type: INSTANCE_TYPE): void;
}
