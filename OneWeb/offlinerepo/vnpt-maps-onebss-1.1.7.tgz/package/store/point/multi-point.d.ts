import { MultiPoint } from '../../_basic';
export declare class MultiPointStore {
    private static _iterator;
    private static _multiPointStorage;
    constructor();
    static getIterator(): number;
    static addInstance(multiPoint: MultiPoint): void;
    static getInstance(id: string): MultiPoint | undefined;
    static removeInstance(id: string): void;
}
