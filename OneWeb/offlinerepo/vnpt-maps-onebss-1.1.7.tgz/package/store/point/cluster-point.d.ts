import { ClusterPoint } from '../../_basic';
export declare class ClusterPointStore {
    private static _iterator;
    private static _clusterPointStorage;
    constructor();
    static getIterator(): number;
    static addInstance(clusterPoint: ClusterPoint): void;
    static getInstance(id: string): ClusterPoint | undefined;
    static removeInstance(id: string): void;
}
