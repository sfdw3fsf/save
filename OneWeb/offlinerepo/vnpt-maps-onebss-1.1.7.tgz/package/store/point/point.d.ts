import { Point } from '../../_basic';
export declare class PointStore {
    private static _iterator;
    private static _pointStorage;
    constructor();
    static getIterator(): number;
    static addInstance(point: Point): void;
    static getInstance(id: string): Point | undefined;
    static removeInstance(id: string): void;
}
