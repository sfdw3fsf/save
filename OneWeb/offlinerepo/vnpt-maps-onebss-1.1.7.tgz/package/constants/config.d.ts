export declare const DOMAIN_MAPS = "https://maps.vnpt.vn";
export declare const TOKEN = "992def364c654ad39461ef1878f99c62";
export declare const STYLE_URL: string;
export declare const GLYPSH_URL: string;
export declare const TILES_URL: string;
export declare const SPRITE_URL: string;
