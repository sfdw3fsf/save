export declare const DEFAULT_MAP_OPTIONS: {
    center: number[];
    id: string;
    maxZoom: number;
    minZoom: number;
    showZoomControl: boolean;
    showFullscreen: boolean;
    styleUrl: string;
    token: string;
    zoom: number;
    zoomControlPosition: string;
    fullscreenPosition: string;
    pitch: number;
    bearing: number;
    isRaster: boolean;
};
export declare const DEFAULT_BOUNDS_OPTIONS: {
    linear: boolean;
    maxZoom: number;
    padding: {
        top: number;
        bottom: number;
        left: number;
        right: number;
    };
    offset: number[];
};
