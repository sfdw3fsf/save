export declare const LIST_OF_LONGITUDE: string[];
export declare const LIST_OF_LATITUDE: string[];
export declare const GLOBAL_CONFIG: {
    basemapUrl: string;
    sdkUrl: string;
    apiUrl: string;
    apiBasemapUrl: string;
    directionsUrl: string;
};
export declare const GlobalDictionary: {
    error: {
        expectedArrayLayer: string;
        expectedArray: string;
        expectedString: string;
        expectedObject: string;
        expectedForPopupCont: string;
        expectedForPopupPos: string;
        expectedCoordField: string;
        expectedJSON: string;
        expectedValidLayerArr: string;
        expectedValidLayer: string;
        expectedPoint: string;
        expectedBufferPoint: string;
        expectedPolyline: string;
        expectedBufferPolyline: string;
        expectedPolygon: string;
        expectedBufferPolygon: string;
        expectedBuffer: string;
        expectedCovidKey: string;
        expectedOneValidData: string;
        expectedTypeAsString: string;
        expectedStringToken: string;
        expectedArrayPolygon: string;
        expectedStringFromIsochrone: string;
        complexPolygon: string;
        nanInput: string;
        checkInput: string;
        checkInputCenter: string;
        checkInputRad: string;
        splitCheckInputLine: string;
        needSizePolygon: string;
        needValidSizePolygon: string;
        needSizePolyline: string;
        needValidSizePolyline: string;
        invalidPositionInput: string;
        invalidData: string;
        mqttPortInput: string;
        mqttHostInput: string;
        mqttIdInput: string;
        mqttUsernameInput: string;
        mqttPasswordInput: string;
        mqttCallback: string;
        mqttTopic: string;
    };
    geodecode: {
        infor: string;
    };
    popup: {
        geojsonType: string;
        geojsonCoord: string;
        center: string;
        radius: string;
        length: string;
        area: string;
        nia: string;
    };
    search: {
        errorExpectedOptions: string;
        errorExpectedOptionsLayer: string;
        textNotFound: string;
        textCancel: string;
        textPlaceholder: string;
    };
    basemapApiRoute: {
        continueOn: {
            text: string;
            icon: string;
            sign: number;
        };
        turnSlightRight: {
            text: string;
            icon: string;
            sign: number;
        };
        turnRight: {
            text: string;
            icon: string;
            sign: number;
        };
        turnSharpRight: {
            text: string;
            icon: string;
            sign: number;
        };
        finish: {
            text: string;
            icon: string;
            sign: number;
        };
        viaReached: {
            text: string;
            icon: string;
            sign: number;
        };
        keepRight: {
            text: string;
            icon: string;
            sign: number;
        };
        atRoundabout: {
            text: string;
            icon: string;
            sign: number;
        };
        unk8: {
            text: string;
            icon: string;
            sign: number;
        };
        turnSlightLeft: {
            text: string;
            icon: string;
            sign: number;
        };
        turnLeft: {
            text: string;
            icon: string;
            sign: number;
        };
        turnSharpLeft: {
            text: string;
            icon: string;
            sign: number;
        };
        unk6: {
            text: string;
            icon: string;
            sign: number;
        };
        keepLeft: {
            text: string;
            icon: string;
            sign: number;
        };
        uTurn: {
            text: string;
            icon: string;
            sign: number;
        };
        comeNextPlace: {
            text: string;
            icon: string;
            sign: number;
        };
    };
    basemapApi: {
        distance: string;
        time: string;
        instructions: string;
        hrs: string;
        mins: string;
        secs: string;
        total: string;
    };
    fullScreen: {
        fullScreen: string;
        exitFullScreen: string;
    };
    locate: {
        title: string;
    };
};
export declare const ListOfStation: {
    address: string;
    extended_address: string;
    gid: string;
    lat: string;
    long: string;
}[];
