export declare const DEFAULT_POPUP_OPTIONS: {
    id: string;
    offset: number;
};
