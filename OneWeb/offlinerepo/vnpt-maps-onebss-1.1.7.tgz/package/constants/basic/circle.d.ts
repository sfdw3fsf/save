export declare const DEFAULT_CIRCLE_OPTIONS: {
    id: string;
    color: string;
    dashArray: number[];
    fillOpacity: number;
    fillColor: string;
    opacity: number;
    weight: number;
};
