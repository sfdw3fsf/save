export declare const DEFAULT_POLYGON_OPTIONS: {
    id: string;
    color: string;
    dashArray: number[];
    fillColor: string;
    fillOpacity: number;
    opacity: number;
    weight: number;
};
export declare const DEFAULT_MULTI_POLYGON_OPTIONS: {
    id: string;
    color: string;
    dashArray: number[];
    fillColor: string;
    fillOpacity: number;
    opacity: number;
    weight: number;
};
