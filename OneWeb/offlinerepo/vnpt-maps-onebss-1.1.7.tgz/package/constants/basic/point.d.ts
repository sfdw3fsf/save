export declare const DEFAULT_POINT_OPTIONS: {
    id: string;
    className: string;
    iconHeight: number;
    iconOpacity: number;
    iconUrl: string;
    iconWidth: number;
    isDraggable: boolean;
};
export declare const DEFAULT_MULTI_POINT_OPTIONS: {
    id: string;
    className: string;
    iconHeight: number;
    iconOpacity: number;
    iconUrl: string;
    iconWidth: number;
    isDraggable: boolean;
};
