export declare const DEFAULT_CLUSTER_POINT_OPTIONS: {
    id: string;
    clickToZoom: boolean;
    clusterColors: string[];
    clusterRadiuses: number[];
    clusterSteps: number[];
    iconUrl: string;
    iconSize: number;
    iconOpacity: number;
    clusterOpacity: number;
};
