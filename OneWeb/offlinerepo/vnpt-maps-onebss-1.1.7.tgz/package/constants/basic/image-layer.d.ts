export declare const DEFAULT_IMAGE_LAYER_OPTIONS: {
    id: string;
    opacity: number;
    url: string;
    fadeDuration: number;
};
