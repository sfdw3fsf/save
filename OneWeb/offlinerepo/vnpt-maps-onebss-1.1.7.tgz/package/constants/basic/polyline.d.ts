export declare const DEFAULT_POLYLINE_OPTIONS: {
    id: string;
    color: string;
    dashArray: number[];
    lineCap: string;
    opacity: number;
    weight: number;
};
export declare const DEFAULT_MULTI_POLYLINE_OPTIONS: {
    id: string;
    color: string;
    dashArray: number[];
    lineCap: string;
    opacity: number;
    weight: number;
};
