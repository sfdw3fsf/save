import { Map } from '../core';
import { MapOptions } from '../models';
export declare function initMap(container: string, options?: MapOptions): Map;
