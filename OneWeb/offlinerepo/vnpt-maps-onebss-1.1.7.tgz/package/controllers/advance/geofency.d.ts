import { Geofency } from '../../_advance';
export declare function initGeofency(): Geofency;
