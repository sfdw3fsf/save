import { Encryption } from '../../_advance';
export declare function initEncryption(): Encryption;
