import { Projection } from '../../_advance';
export declare function initProjection(): Projection;
