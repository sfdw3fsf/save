import { GeometryServices } from '../../_advance';
export declare function initGeometryService(): GeometryServices;
