import { BasemapAPI } from '../../_advance';
export declare function initBasemapApi(): BasemapAPI;
