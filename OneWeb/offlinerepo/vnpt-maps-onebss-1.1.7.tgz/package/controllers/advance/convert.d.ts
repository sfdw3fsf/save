import { Convert } from '../../_advance';
export declare function initConvert(): Convert;
