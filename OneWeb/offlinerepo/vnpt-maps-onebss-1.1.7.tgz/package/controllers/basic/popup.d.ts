import { Popup } from '../../_basic';
import { Coordinates, PopupOptions } from '../../models';
export declare function initPopup(coordinates: Coordinates, content: string, options?: PopupOptions): Popup;
