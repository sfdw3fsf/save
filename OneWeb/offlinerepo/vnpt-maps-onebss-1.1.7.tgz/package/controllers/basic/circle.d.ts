import { Circle } from '../../_basic';
import { CircleOptions, Coordinates } from '../../models';
export declare function initCircle(coordinates: Coordinates, radius: number, options?: CircleOptions): Circle;
