import { MultiPolyline, Polyline } from '../../_basic';
import { CoordinatesArray, GeoJSON, GeoJSONCollection, PolylineOptions } from '../../models';
export declare function initPolyline(data: CoordinatesArray | GeoJSON, options?: PolylineOptions): Polyline;
export declare function initMultiPolyline(data: CoordinatesArray[] | GeoJSONCollection, options?: PolylineOptions): MultiPolyline;
