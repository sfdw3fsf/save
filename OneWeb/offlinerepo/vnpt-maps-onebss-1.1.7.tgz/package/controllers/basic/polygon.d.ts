import { MultiPolygon, Polygon } from '../../_basic';
import { GeoJSON, GeoJSONCollection, PolygonCoordinates, PolygonOptions } from '../../models';
export declare function initPolygon(data: PolygonCoordinates | GeoJSON, options?: PolygonOptions): Polygon;
export declare function initMultiPolygon(data: PolygonCoordinates[] | GeoJSONCollection, options?: PolygonOptions): MultiPolygon;
