import { ClusterPointOptions, Coordinates, CoordinatesArray, GeoJSON, GeoJSONCollection, PointOptions } from '../../models';
import { ClusterPoint, MultiPoint, Point } from '../../_basic';
import { PointLngLat } from '../../adapter';
export declare function initPoint(coordinates: Coordinates | GeoJSON, options?: PointOptions): Point;
export declare function initMultiPoint(data: CoordinatesArray | PointLngLat[], options?: PointOptions): MultiPoint;
export declare function initClusterPoint(data: CoordinatesArray | GeoJSONCollection, options?: ClusterPointOptions): ClusterPoint;
