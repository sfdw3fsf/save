import { ImageLayer } from '../../_basic';
import { CoordinatesArray, ImageLayerOptions } from '../../models';
export declare function initImageLayer(coordinates: CoordinatesArray, options?: ImageLayerOptions): ImageLayer;
