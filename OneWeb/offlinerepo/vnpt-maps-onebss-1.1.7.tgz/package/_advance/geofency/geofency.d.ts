import { Coordinates, LineCoordinates, PolygonCoordinates } from '../../models';
export declare class Geofency {
    constructor();
    isLocationOnEdgeLine(point: Coordinates, polyline: LineCoordinates, tolerance?: number): boolean;
    isLocationOnEdgeFill(point: Coordinates, polygon: PolygonCoordinates): boolean;
    pointToLineDistance(point: Coordinates, polyline: LineCoordinates, units?: string): number;
}
