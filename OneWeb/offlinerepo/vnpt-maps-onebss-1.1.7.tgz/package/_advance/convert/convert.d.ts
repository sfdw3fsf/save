export declare class Convert {
    constructor();
    distance(distance: number, fromUnits: any, toUnits: any): any;
    area(area: number, fromUnits: any, toUnits: any): any;
    degreesToRadians(area: number): any;
    degreesToDistance(degrees: number, resultUnits: any): any;
    radiansToDegrees(radians: number): any;
    radiansToDistance(radians: number, resultUnits: any): any;
    distanceToDegrees(distance: number, unit: any): any;
    distanceToRadians(distance: number, unit: any): any;
    coordinatesToDMS(distance: number, unit: any): any;
}
