export declare class Projection {
    constructor();
    transformFromWGS84(coordinates: number[], toSRID: string): any;
    transformToWGS84(coordinates: number[], fromSRID: string): any;
    getProjection(code: string): any;
    newProjection(code: string, projectionDefs: string): any;
    transform(coordinates: number[], fromSRID: string, toSRID: string): any;
    transformPoly(coordinates: number[][], fromSRID: string, toSRID: string): any;
    transformVn2000ToWgs84ByCityCode(coordinates: number[], code: string): any;
}
