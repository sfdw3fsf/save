import { Polygon } from './../../_basic/polygon/polygon';
export declare class GeometryServices {
    constructor();
    splitPolyline(polylineCoordinates: any, splitterCoordinates: any): any;
    splitPolygon(polylineCoordinates: any, splitterCoordinates: any): any;
    splitPolylineToMultiSegments(polylineValue: any, numberOfSegments: any, optionsValue: any): any;
    splitPolygonToMultiSegments(polygonValue: any, splitterValue: any, numberOfSegments: any): any;
    intersectPolyline(polylineCoord1: any, polylineCoord2: any): any;
    intersectPolylgon(polygon1: Polygon, polygon2: Polygon): any;
    mergePolyline(targetLineCoordinates: any, mergeLineCoordinates: any): any;
    mergePolygon(targetPolygon: Polygon, merge_polygons: Polygon): any;
    polygonClipperUnion(sourcePolygon: Polygon, clipperpolygons: Polygon): any;
    polygonClipperDifference(sourcePolygon: Polygon, clipperpolygons: Polygon): any;
    polygonClipperIntersect(sourcePolygon: Polygon, clipperpolygons: Polygon): any;
    polygonClipperXor(sourcePolygon: Polygon, clipperpolygons: Polygon): any;
}
