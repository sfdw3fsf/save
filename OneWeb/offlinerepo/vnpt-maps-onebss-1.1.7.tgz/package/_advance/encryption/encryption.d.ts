export declare class Encryption {
    constructor();
    encoded(data: any): void;
    decoded(encodedString: any): any;
    decode(encodedString: any): void;
    encode(data: any): void;
}
